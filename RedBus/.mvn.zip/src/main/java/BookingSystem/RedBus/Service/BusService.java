package BookingSystem.RedBus.Service;


import BookingSystem.RedBus.Entity.Bus;
import BookingSystem.RedBus.Entity.User;
import BookingSystem.RedBus.Repo.BusRepository;
import BookingSystem.RedBus.Repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class BusService {

    @Autowired
    BusRepository busRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    public String addBus(Bus bus) {
        busRepository.save(bus);
        return "Added Bus";
    }
    public String removeBus(Bus bus) {
        busRepository.delete(bus);
        return "Removed Bus";
    }
    public String saveNewAdmin(User admin){
        admin.setPassword(passwordEncoder.encode(admin.getPassword()));
        admin.setRole("ADMIN");
        userRepository.save(admin);
        return "Saved Admin";
    }

}
