package BookingSystem.RedBus.Service;


import BookingSystem.RedBus.Entity.Booking;
import BookingSystem.RedBus.Entity.User;
import BookingSystem.RedBus.Repo.BookingRepository;
import BookingSystem.RedBus.Repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class BookingService {
    @Autowired
    UserRepository userRepository;

    @Autowired
    BookingRepository bookingRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    public String saveUser(User user){
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole("USER");
        userRepository.save(user);
        return "Saved User";
    }
    public String saveBooking(Booking booking){
        bookingRepository.save(booking);
        return "Saved Booking";
    }



}
