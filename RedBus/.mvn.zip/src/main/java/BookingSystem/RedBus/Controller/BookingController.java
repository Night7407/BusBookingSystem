package BookingSystem.RedBus.Controller;


import BookingSystem.RedBus.Entity.Booking;
import BookingSystem.RedBus.Entity.User;
import BookingSystem.RedBus.Service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/bookings")
public class BookingController {

    @Autowired
    BookingService bookingService;

    @PostMapping("/add")
    public String addUser(@RequestBody User user){
        return bookingService.saveUser(user);
    }
    @PostMapping("/booking")
    public String booking(@RequestBody Booking booking){
        return bookingService.saveBooking(booking);
    }
}
