package BookingSystem.RedBus.Controller;

import BookingSystem.RedBus.Entity.User;
import BookingSystem.RedBus.Service.BusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AddAdminController {
    @Autowired
    BusService busservice;

    @PostMapping("/init-admin")
    public String createAdmin(@RequestBody User user) {
        return busservice.saveNewAdmin(user);
    }
}
