package BookingSystem.RedBus.Repo;

import BookingSystem.RedBus.Entity.Bus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BusRepository extends JpaRepository<Bus,Long> {
}
